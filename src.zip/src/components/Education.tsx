"use client";

import { motion } from "framer-motion";
import {
  GraduationCap,
  MapPin,
  CalendarDays,
  ArrowUpRight,
  Sparkles,
  School,
} from "lucide-react";

const education = [
  {
    number: "01",
    status: "CURRENT",
    period: "Pursuing",
    degree: "Bachelor of Science in Information Technology",
    shortDegree: "B.Sc. Information Technology",
    institution: "Karmaveer Bhaurao Patil College",
    location: "Urun Ishwarpur, Maharashtra",
    description:
      "Currently pursuing B.Sc. in Information Technology, building a strong foundation in programming, web development, databases and software development.",
    icon: Sparkles,
    tags: ["B.Sc. IT", "Programming", "Web Development"],
  },
  {
    number: "02",
    status: "COMPLETED",
    period: "2021",
    degree: "Diploma in Computer Engineering",
    shortDegree: "Diploma — Computer Engineering",
    institution: "Nanasaheb Mahadik Polytechnic Institute",
    location: "Peth, Maharashtra",
    description:
      "Completed Diploma in Computer Engineering with a strong technical foundation in programming, computer engineering concepts and software technologies.",
    grade: "78.47%",
    icon: GraduationCap,
    tags: ["Computer Engineering", "Programming", "Technical Studies"],
  },
  {
    number: "03",
    status: "COMPLETED",
    period: "HSC",
    degree: "Higher Secondary Certificate",
    shortDegree: "HSC",
    institution: "Karmaveer Bhaurao Patil College",
    location: "Urun Ishwarpur, Maharashtra",
    description:
      "Completed Higher Secondary Certificate education, providing the academic foundation for further studies in computer engineering and information technology.",
    grade: "47.23%",
    icon: School,
    tags: ["HSC", "Higher Secondary Education"],
  },
  {
    number: "04",
    status: "COMPLETED",
    period: "SSC",
    degree: "Secondary School Certificate",
    shortDegree: "SSC",
    institution: "Yashwant Highschool",
    location: "Ishwarpur, Maharashtra",
    description:
      "Completed Secondary School Certificate education and began the academic journey that led towards technical and information technology studies.",
    grade: "64.80%",
    icon: School,
    tags: ["SSC", "Secondary Education"],
  },
];

export default function Education() {
  return (
    <section
      id="education"
      className="relative overflow-hidden bg-[#080808] py-28 sm:py-36"
    >
      {/* =====================================================
          BACKGROUND
      ===================================================== */}

      <div className="pointer-events-none absolute inset-0">
        {/* Orange ambient glow */}

        <div className="absolute left-[-15%] top-[18%] h-[500px] w-[500px] rounded-full bg-[#ff5a1f]/[0.055] blur-[160px]" />

        {/* White ambient glow */}

        <div className="absolute bottom-[5%] right-[-12%] h-[450px] w-[450px] rounded-full bg-white/[0.02] blur-[150px]" />

        {/* Grid */}

        <div
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.8) 1px, transparent 1px)",
            backgroundSize: "90px 90px",
          }}
        />

        {/* Top fade */}

        <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-[#080808] to-transparent" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        {/* =====================================================
            SECTION HEADER
        ===================================================== */}

        <motion.div
          initial={{
            opacity: 0,
            y: 45,
          }}
          whileInView={{
            opacity: 1,
            y: 0,
          }}
          viewport={{
            once: true,
            amount: 0.25,
          }}
          transition={{
            duration: 0.8,
            ease: [0.22, 1, 0.36, 1],
          }}
          className="mb-20 max-w-5xl"
        >
          {/* Label */}

          <div className="mb-7 flex items-center gap-4">
            <span className="h-px w-12 bg-[#ff5a1f]" />

            <span className="text-[11px] font-semibold tracking-[0.35em] text-[#ff5a1f]">
              EDUCATION
            </span>
          </div>

          {/* Heading */}

          <h2 className="text-5xl font-semibold leading-[0.9] tracking-[-0.06em] text-white sm:text-6xl lg:text-[7rem]">
            The foundation
            <br />
            <span className="text-white/25">behind the developer.</span>
          </h2>

          {/* Description */}

          <p className="mt-9 max-w-2xl text-base leading-7 text-white/40 sm:text-lg">
            My academic journey from school education to Information
            Technology has built the technical foundation behind my
            development career.
          </p>
        </motion.div>

        {/* =====================================================
            EDUCATION TIMELINE
        ===================================================== */}

        <div className="relative">
          {/* Timeline Line */}

          <div className="absolute bottom-8 left-[23px] top-8 hidden w-px bg-gradient-to-b from-[#ff5a1f] via-white/10 to-transparent md:block" />

          <div className="space-y-8">
            {education.map((item, index) => {
              const Icon = item.icon;

              return (
                <motion.article
                  key={item.number}
                  initial={{
                    opacity: 0,
                    y: 55,
                  }}
                  whileInView={{
                    opacity: 1,
                    y: 0,
                  }}
                  viewport={{
                    once: true,
                    amount: 0.12,
                  }}
                  transition={{
                    duration: 0.75,
                    delay: index * 0.08,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="relative md:pl-20"
                >
                  {/* =================================================
                      TIMELINE NODE
                  ================================================= */}

                  <div className="absolute left-[9px] top-10 hidden h-7 w-7 items-center justify-center rounded-full border border-[#ff5a1f]/40 bg-[#080808] md:flex">
                    <motion.div
                      initial={{
                        scale: 0.5,
                        opacity: 0.3,
                      }}
                      whileInView={{
                        scale: 1,
                        opacity: 1,
                      }}
                      viewport={{
                        once: true,
                      }}
                      transition={{
                        duration: 0.5,
                        delay: index * 0.08 + 0.2,
                      }}
                      className="h-2 w-2 rounded-full bg-[#ff5a1f] shadow-[0_0_18px_rgba(255,90,31,0.9)]"
                    />
                  </div>

                  {/* =================================================
                      EDUCATION CARD
                  ================================================= */}

                  <div className="group relative overflow-hidden rounded-[2rem] border border-white/[0.08] bg-white/[0.025] transition-all duration-500 hover:border-[#ff5a1f]/25 hover:bg-white/[0.035]">
                    {/* Orange side accent */}

                    <div className="absolute bottom-0 left-0 top-0 w-[2px] bg-gradient-to-b from-[#ff5a1f] via-[#ff5a1f]/40 to-transparent" />

                    {/* Hover glow */}

                    <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-[#ff5a1f]/[0.045] opacity-0 blur-[80px] transition-opacity duration-700 group-hover:opacity-100" />

                    {/* Background Number */}

                    <div className="pointer-events-none absolute right-6 top-1 select-none text-[110px] font-bold leading-none tracking-[-0.1em] text-white/[0.025] sm:right-10 sm:text-[150px]">
                      {item.number}
                    </div>

                    <div className="relative grid gap-9 p-7 sm:p-9 lg:grid-cols-[0.65fr_2fr] lg:gap-14 lg:p-11">
                      {/* =================================================
                          META COLUMN
                      ================================================= */}

                      <div>
                        {/* Icon */}

                        <div className="mb-7 flex h-14 w-14 items-center justify-center rounded-2xl border border-[#ff5a1f]/20 bg-[#ff5a1f]/[0.08]">
                          <Icon
                            size={24}
                            strokeWidth={1.5}
                            className="text-[#ff5a1f]"
                          />
                        </div>

                        {/* Status */}

                        <p className="text-[10px] font-bold tracking-[0.3em] text-[#ff5a1f]">
                          {item.status}
                        </p>

                        {/* Period */}

                        <div className="mt-4 flex items-center gap-2 text-sm text-white/35">
                          <CalendarDays
                            size={15}
                            strokeWidth={1.5}
                            className="text-white/25"
                          />

                          <span>{item.period}</span>
                        </div>

                        {/* Number */}

                        <p className="mt-8 hidden font-mono text-[10px] tracking-[0.2em] text-white/15 lg:block">
                          ACADEMIC / {item.number}
                        </p>
                      </div>

                      {/* =================================================
                          CONTENT COLUMN
                      ================================================= */}

                      <div>
                        {/* Degree */}

                        <div className="mb-5 flex items-start justify-between gap-5">
                          <div>
                            <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/20">
                              {item.shortDegree}
                            </p>

                            <h3 className="max-w-3xl text-3xl font-semibold leading-[1.05] tracking-[-0.04em] text-white sm:text-4xl lg:text-[3.2rem]">
                              {item.degree}
                            </h3>
                          </div>

                          <ArrowUpRight
                            size={23}
                            strokeWidth={1.3}
                            className="mt-1 shrink-0 text-white/15 transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-[#ff5a1f]"
                          />
                        </div>

                        {/* Institution */}

                        <h4 className="text-lg font-medium leading-7 text-white/75 sm:text-xl">
                          {item.institution}
                        </h4>

                        {/* Location */}

                        <div className="mt-3 flex items-start gap-2 text-sm text-white/30">
                          <MapPin
                            size={15}
                            strokeWidth={1.5}
                            className="mt-0.5 shrink-0 text-[#ff5a1f]"
                          />

                          <span>{item.location}</span>
                        </div>

                        {/* =================================================
                            SCORE
                        ================================================= */}

                        {item.grade && (
                          <div className="mt-7 inline-flex items-center gap-4 rounded-full border border-[#ff5a1f]/20 bg-[#ff5a1f]/[0.055] px-4 py-2.5">
                            <span className="text-[9px] font-bold tracking-[0.25em] text-[#ff5a1f]">
                              SCORE
                            </span>

                            <span className="h-3 w-px bg-white/10" />

                            <span className="text-sm font-semibold text-white">
                              {item.grade}
                            </span>
                          </div>
                        )}

                        {/* Divider */}

                        <div className="my-7 h-px bg-white/[0.07]" />

                        {/* Description */}

                        <p className="max-w-3xl text-sm leading-7 text-white/38 sm:text-base">
                          {item.description}
                        </p>

                        {/* Tags */}

                        <div className="mt-7 flex flex-wrap gap-2">
                          {item.tags.map((tag) => (
                            <span
                              key={tag}
                              className="rounded-full border border-white/[0.07] bg-white/[0.015] px-3.5 py-1.5 text-[10px] font-medium tracking-wide text-white/30 transition-all duration-300 group-hover:border-white/[0.12] group-hover:text-white/50"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </div>
        </div>

        {/* =====================================================
            BOTTOM STATEMENT
        ===================================================== */}

        <motion.div
          initial={{
            opacity: 0,
            y: 15,
          }}
          whileInView={{
            opacity: 1,
            y: 0,
          }}
          viewport={{
            once: true,
          }}
          transition={{
            duration: 0.7,
            delay: 0.2,
          }}
          className="mt-16 flex items-center gap-4"
        >
          <span className="h-px w-10 bg-[#ff5a1f]/60" />

          <span className="text-[10px] font-medium tracking-[0.3em] text-white/20">
            LEARNING • BUILDING • EVOLVING
          </span>
        </motion.div>
      </div>
    </section>
  );
}