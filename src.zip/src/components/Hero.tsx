"use client";

import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import {
  ArrowDown,
  ArrowUpRight,
  Download,
  MousePointer2,
} from "lucide-react";

const HeroScene = dynamic(
  () => import("@/components/3d/HeroScene"),
  {
    ssr: false,
    loading: () => null,
  }
);

const technologies = [
  "LARAVEL",
  "PHP",
  "JAVASCRIPT",
  "MYSQL",
  "CORE JAVA",
  "HTML",
  "BOOTSTRAP 5",
  "ADMINLTE",
  "GIT & GITHUB",
];

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen overflow-hidden bg-[#080808] text-white"
    >
      {/* =====================================================
          AMBIENT BACKGROUND
      ===================================================== */}

      <div className="pointer-events-none absolute inset-0 z-0">
        <div
          className="
            absolute
            left-[72%]
            top-[45%]
            h-[560px]
            w-[560px]
            -translate-x-1/2
            -translate-y-1/2
            rounded-full
            bg-[#ff5a1f]/[0.065]
            blur-[130px]
            max-sm:left-1/2
            max-sm:top-[37%]
            max-sm:h-[360px]
            max-sm:w-[360px]
          "
        />

        <div
          className="
            absolute
            left-[76%]
            top-[44%]
            h-[360px]
            w-[360px]
            -translate-x-1/2
            -translate-y-1/2
            rounded-full
            bg-white/[0.02]
            blur-[100px]
            max-sm:left-1/2
            max-sm:top-[37%]
            max-sm:h-[250px]
            max-sm:w-[250px]
          "
        />

        <div
          className="
            absolute
            inset-0
            opacity-[0.045]
            [background-image:linear-gradient(rgba(255,255,255,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.2)_1px,transparent_1px)]
            [background-size:80px_80px]
          "
        />
      </div>

      {/* =====================================================
          3D SCENE
      ===================================================== */}

      <HeroScene />

      {/* =====================================================
          CINEMATIC OVERLAY
      ===================================================== */}

      <div
        className="
          pointer-events-none
          absolute
          inset-0
          z-[1]
          bg-[radial-gradient(circle_at_72%_45%,transparent_0%,rgba(8,8,8,0.025)_22%,rgba(8,8,8,0.32)_48%,#080808_82%)]
          max-sm:bg-[radial-gradient(circle_at_50%_35%,transparent_0%,rgba(8,8,8,0.02)_20%,rgba(8,8,8,0.2)_48%,#080808_78%)]
        "
      />

      {/* =====================================================
          LEFT FADE
      ===================================================== */}

      <div
        className="
          pointer-events-none
          absolute
          inset-0
          z-[1]
          bg-[linear-gradient(90deg,rgba(8,8,8,0.24)_0%,rgba(8,8,8,0.04)_48%,transparent_72%)]
          max-sm:bg-[linear-gradient(180deg,rgba(8,8,8,0.05)_0%,rgba(8,8,8,0.08)_35%,rgba(8,8,8,0.72)_58%,#080808_78%)]
        "
      />

      {/* =====================================================
          CONTENT
      ===================================================== */}

      <div className="relative z-10 mx-auto flex min-h-screen max-w-[1600px] flex-col px-5 pb-8 pt-28 sm:px-8 lg:px-12">
        {/* =================================================
            TOP METADATA
        ================================================= */}

        <div className="flex items-center justify-between border-b border-white/10 pb-5">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.45,
              ease: "easeOut",
            }}
            className="flex items-center gap-3"
          >
            <span className="h-2 w-2 rounded-full bg-[#ff5a1f] shadow-[0_0_12px_#ff5a1f]" />

            <span className="text-[10px] font-medium uppercase tracking-[0.28em] text-white/60 sm:text-xs">
              PHP Laravel Developer
            </span>
          </motion.div>

          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{
              duration: 0.4,
              delay: 0.15,
            }}
            className="hidden text-xs uppercase tracking-[0.25em] text-white/35 sm:block"
          >
            2026 / Portfolio
          </motion.span>
        </div>

        {/* =================================================
            MAIN HERO
        ================================================= */}

        <div className="flex flex-1 items-center">
          <div className="w-full">
            <div className="relative">
              {/* SMALL LABEL */}

              <motion.div
                initial={{ opacity: 0, x: -18 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: 0.45,
                  delay: 0.15,
                  ease: "easeOut",
                }}
                className="mb-5 flex items-center gap-3"
              >
                <span className="h-px w-10 bg-[#ff5a1f]" />

                <span className="text-[10px] uppercase tracking-[0.3em] text-white/40">
                  I design & build
                </span>
              </motion.div>

              {/* NAME */}

              <div className="relative">
                <motion.h1
                  initial={{
                    opacity: 0,
                    y: 35,
                  }}
                  animate={{
                    opacity: 1,
                    y: 0,
                  }}
                  transition={{
                    duration: 0.55,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="
                    relative
                    z-10
                    select-none
                    text-[18vw]
                    font-black
                    leading-[0.72]
                    tracking-[-0.075em]
                    sm:text-[15vw]
                    lg:text-[13vw]
                    max-sm:text-[17vw]
                  "
                >
                  PRANIL
                </motion.h1>

                <motion.h1
                  initial={{
                    opacity: 0,
                    y: 35,
                  }}
                  animate={{
                    opacity: 1,
                    y: 0,
                  }}
                  transition={{
                    duration: 0.55,
                    delay: 0.07,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="
                    relative
                    z-10
                    select-none
                    text-[18vw]
                    font-black
                    leading-[0.82]
                    tracking-[-0.075em]
                    text-transparent
                    [-webkit-text-stroke:1px_rgba(255,255,255,0.38)]
                    sm:text-[15vw]
                    lg:text-[13vw]
                    max-sm:text-[17vw]
                  "
                >
                  MALEKAR
                </motion.h1>

                <motion.div
                  initial={{
                    width: 0,
                  }}
                  animate={{
                    width: "clamp(80px, 15vw, 230px)",
                  }}
                  transition={{
                    delay: 0.5,
                    duration: 0.55,
                    ease: "easeOut",
                  }}
                  className="
                    mt-5
                    h-[3px]
                    bg-[#ff5a1f]
                    shadow-[0_0_18px_rgba(255,90,31,0.45)]
                  "
                />
              </div>

              {/* DESCRIPTION */}

              <motion.div
                initial={{
                  opacity: 0,
                  y: 18,
                }}
                animate={{
                  opacity: 1,
                  y: 0,
                }}
                transition={{
                  delay: 0.58,
                  duration: 0.5,
                  ease: "easeOut",
                }}
                className="
                  mt-10
                  grid
                  gap-8
                  lg:grid-cols-[1fr_auto]
                  max-sm:mt-8
                "
              >
                <div className="max-w-xl">
                  <p className="text-base leading-7 text-white/55 sm:text-lg">
                    I build modern web applications with a focus on
                    clean interfaces, scalable backend systems and
                    meaningful user experiences.
                  </p>

                  <div className="mt-7 flex flex-wrap gap-3">
                    <a
                      href="#projects"
                      className="
                        group
                        inline-flex
                        items-center
                        gap-3
                        rounded-full
                        bg-[#ff5a1f]
                        px-6
                        py-3
                        text-xs
                        font-semibold
                        uppercase
                        tracking-[0.15em]
                        text-black
                        transition-all
                        duration-200
                        hover:scale-[1.03]
                        hover:shadow-[0_0_30px_rgba(255,90,31,0.3)]
                      "
                    >
                      View My Work

                      <ArrowUpRight
                        size={16}
                        className="
                          transition-transform
                          duration-200
                          group-hover:translate-x-1
                          group-hover:-translate-y-1
                        "
                      />
                    </a>

                    <a
                      href="/resume.pdf"
                      download
                      className="
                        group
                        inline-flex
                        items-center
                        gap-3
                        rounded-full
                        border
                        border-white/15
                        bg-white/[0.03]
                        px-6
                        py-3
                        text-xs
                        font-semibold
                        uppercase
                        tracking-[0.15em]
                        text-white/80
                        backdrop-blur-md
                        transition-all
                        duration-200
                        hover:border-white/30
                        hover:bg-white/[0.07]
                      "
                    >
                      Resume

                      <Download
                        size={15}
                        className="
                          transition-transform
                          duration-200
                          group-hover:translate-y-1
                        "
                      />
                    </a>
                  </div>
                </div>

                <div className="flex items-end lg:pr-10">
                  <div className="border-l border-white/10 pl-5">
                    <p className="mb-2 text-[9px] uppercase tracking-[0.28em] text-white/30">
                      Currently focused on
                    </p>

                    <p className="text-sm font-medium text-white/70">
                      PHP Laravel Development
                    </p>

                    <p className="mt-1 text-xs text-white/35">
                      Laravel / PHP / MySQL
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* =================================================
            BOTTOM BAR
        ================================================= */}

        <div
          className="
            mt-10
            flex
            flex-col
            justify-between
            gap-5
            border-t
            border-white/10
            pt-5
            sm:flex-row
            sm:items-center
          "
        >
          <div className="flex items-center gap-3 text-white/30">
            <MousePointer2 size={14} />

            <span className="text-[9px] uppercase tracking-[0.25em]">
              Move your cursor
            </span>
          </div>

          <div className="flex max-w-full items-center gap-4 overflow-hidden">
            <div className="flex animate-[marquee_24s_linear_infinite] gap-6 whitespace-nowrap">
              {technologies.map((tech) => (
                <span
                  key={tech}
                  className="
                    text-[9px]
                    font-medium
                    tracking-[0.22em]
                    text-white/25
                  "
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <motion.a
            href="#about"
            animate={{
              y: [0, 4, 0],
            }}
            transition={{
              duration: 2.4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="
              flex
              items-center
              gap-2
              text-white/45
              transition-colors
              duration-200
              hover:text-white
            "
          >
            <span className="text-[9px] uppercase tracking-[0.25em]">
              Scroll
            </span>

            <ArrowDown size={14} />
          </motion.a>
        </div>
      </div>
    </section>
  );
}