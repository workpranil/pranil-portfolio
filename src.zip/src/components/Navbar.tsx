"use client";

import {
  AnimatePresence,
  motion,
  useScroll,
  useTransform,
} from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useState } from "react";

const navItems = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Education", href: "#education" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const { scrollY } = useScroll();

  const width = useTransform(scrollY, [0, 120], ["100%", "92%"]);
  const top = useTransform(scrollY, [0, 120], [0, 14]);

  return (
    <>
      {/* =====================================================
          DESKTOP / MAIN NAVBAR
      ===================================================== */}

      <motion.header
        style={{ width, top }}
        className="fixed left-1/2 z-[100] -translate-x-1/2 px-3 sm:px-0"
      >
        <motion.div
          animate={{
            backgroundColor: open
              ? "rgba(8,8,8,0.98)"
              : "rgba(8,8,8,0.72)",

            borderColor: open
              ? "rgba(255,255,255,0.12)"
              : "rgba(255,255,255,0.09)",
          }}
          transition={{ duration: 0.35 }}
          className="
            border
            backdrop-blur-2xl
            shadow-[0_15px_60px_rgba(0,0,0,0.35)]
          "
        >
          <div className="flex items-center justify-between px-4 py-3 sm:px-5">
            {/* =================================================
                LOGO
            ================================================= */}

            <a
              href="#home"
              onClick={() => setOpen(false)}
              className="group flex items-center gap-3 text-white"
            >
              <motion.div
                whileHover={{
                  rotate: 90,
                  scale: 1.05,
                }}
                transition={{
                  duration: 0.45,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="
                  relative
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  border
                  border-white/10
                  bg-white
                  text-black
                "
              >
                <span className="text-sm font-black tracking-[-0.05em]">
                  P
                </span>

                <span
                  className="
                    absolute
                    -right-1
                    -top-1
                    h-2
                    w-2
                    rounded-full
                    bg-[#ff5a1f]
                    shadow-[0_0_12px_rgba(255,90,31,0.8)]
                  "
                />
              </motion.div>

              <div className="hidden leading-none sm:block">
                <p className="text-sm font-black tracking-[-0.04em]">
                  PRANIL
                </p>

                <p
                  className="
                    mt-1
                    text-[8px]
                    font-bold
                    uppercase
                    tracking-[0.24em]
                    text-white/35
                  "
                >
                  Full Stack Developer
                </p>
              </div>
            </a>

            {/* =================================================
                DESKTOP NAV
            ================================================= */}

            <nav className="hidden items-center lg:flex">
              {navItems.map((item, index) => (
                <motion.a
                  key={item.label}
                  href={item.href}
                  whileHover={{ y: -2 }}
                  className="
                    group
                    relative
                    px-3
                    py-3
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-white/55
                    transition-colors
                    duration-300
                    hover:text-white
                  "
                >
                  <span className="relative z-10">
                    {item.label}
                  </span>

                  {/* Orange underline */}

                  <span
                    className="
                      absolute
                      bottom-1
                      left-3
                      right-3
                      h-[1px]
                      origin-left
                      scale-x-0
                      bg-[#ff5a1f]
                      transition-transform
                      duration-300
                      group-hover:scale-x-100
                    "
                  />

                  {/* Active dot */}

                  {index === 0 && (
                    <span
                      className="
                        absolute
                        right-1
                        top-2
                        h-1
                        w-1
                        rounded-full
                        bg-[#ff5a1f]
                        shadow-[0_0_8px_rgba(255,90,31,0.9)]
                      "
                    />
                  )}
                </motion.a>
              ))}
            </nav>

            {/* =================================================
                RIGHT SIDE
            ================================================= */}

            <div className="flex items-center gap-2">
              {/* Let's Talk */}

              <motion.a
                href="#contact"
                whileHover={{
                  y: -2,
                }}
                whileTap={{
                  scale: 0.97,
                }}
                className="
                  group
                  hidden
                  items-center
                  gap-2
                  border
                  border-[#ff5a1f]
                  bg-[#ff5a1f]
                  px-5
                  py-3
                  text-[10px]
                  font-black
                  uppercase
                  tracking-[0.14em]
                  text-black
                  transition-all
                  duration-300
                  hover:bg-transparent
                  hover:text-[#ff5a1f]
                  sm:flex
                "
              >
                <span>Let&apos;s Talk</span>

                <ArrowUpRight
                  size={14}
                  className="
                    transition-transform
                    duration-300
                    group-hover:rotate-45
                  "
                />
              </motion.a>

              {/* Mobile Menu Button */}

              <button
                type="button"
                aria-label={
                  open
                    ? "Close navigation menu"
                    : "Open navigation menu"
                }
                aria-expanded={open}
                onClick={() => setOpen((value) => !value)}
                className="
                  flex
                  h-11
                  w-11
                  items-center
                  justify-center
                  border
                  border-white/10
                  bg-white/[0.03]
                  text-white
                  transition-colors
                  duration-300
                  hover:border-[#ff5a1f]
                  hover:text-[#ff5a1f]
                  lg:hidden
                "
              >
                <AnimatePresence mode="wait">
                  {open ? (
                    <motion.span
                      key="close"
                      initial={{
                        rotate: -90,
                        opacity: 0,
                      }}
                      animate={{
                        rotate: 0,
                        opacity: 1,
                      }}
                      exit={{
                        rotate: 90,
                        opacity: 0,
                      }}
                      transition={{
                        duration: 0.2,
                      }}
                    >
                      <X size={19} />
                    </motion.span>
                  ) : (
                    <motion.span
                      key="menu"
                      initial={{
                        rotate: 90,
                        opacity: 0,
                      }}
                      animate={{
                        rotate: 0,
                        opacity: 1,
                      }}
                      exit={{
                        rotate: -90,
                        opacity: 0,
                      }}
                      transition={{
                        duration: 0.2,
                      }}
                    >
                      <Menu size={19} />
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            </div>
          </div>

          {/* Small orange bottom line */}

          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{
              duration: 1.2,
              ease: [0.22, 1, 0.36, 1],
            }}
            className="
              h-[1px]
              origin-left
              bg-gradient-to-r
              from-[#ff5a1f]
              via-[#ff5a1f]/40
              to-transparent
            "
          />
        </motion.div>
      </motion.header>

      {/* =====================================================
          FULLSCREEN MOBILE MENU
      ===================================================== */}

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{
              clipPath: "inset(0 0 100% 0)",
            }}
            animate={{
              clipPath: "inset(0 0 0% 0)",
            }}
            exit={{
              clipPath: "inset(0 0 100% 0)",
            }}
            transition={{
              duration: 0.65,
              ease: [0.22, 1, 0.36, 1],
            }}
            className="
              fixed
              inset-0
              z-[90]
              flex
              flex-col
              justify-between
              bg-[#080808]
              px-6
              pb-8
              pt-32
              text-white
              sm:px-10
            "
          >
            {/* Background grid */}

            <div
              className="
                pointer-events-none
                absolute
                inset-0
                opacity-50
                [background-image:linear-gradient(rgba(255,255,255,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.035)_1px,transparent_1px)]
                [background-size:45px_45px]
              "
            />

            {/* Orange glow */}

            <div
              className="
                pointer-events-none
                absolute
                right-[-120px]
                top-[20%]
                h-[350px]
                w-[350px]
                rounded-full
                bg-[#ff5a1f]/10
                blur-[120px]
              "
            />

            <div className="relative z-10">
              {/* Header */}

              <div className="mb-8 flex items-center justify-between">
                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.25em]
                    text-[#ff5a1f]
                  "
                >
                  Navigation
                </p>

                <p
                  className="
                    font-mono
                    text-[9px]
                    uppercase
                    tracking-[0.15em]
                    text-white/25
                  "
                >
                  PM / 2026
                </p>
              </div>

              {/* Nav Items */}

              <div className="overflow-hidden">
                {navItems.map((item, index) => (
                  <motion.a
                    key={item.label}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    initial={{
                      y: 80,
                      opacity: 0,
                    }}
                    animate={{
                      y: 0,
                      opacity: 1,
                    }}
                    transition={{
                      delay: 0.08 + index * 0.07,
                      duration: 0.65,
                      ease: [0.22, 1, 0.36, 1],
                    }}
                    className="
                      group
                      flex
                      items-center
                      justify-between
                      border-b
                      border-white/10
                      py-4
                    "
                  >
                    <span
                      className="
                        text-5xl
                        font-black
                        tracking-[-0.07em]
                        text-white
                        transition-colors
                        duration-300
                        group-hover:text-[#ff5a1f]
                        sm:text-6xl
                      "
                    >
                      {item.label}
                    </span>

                    <span
                      className="
                        font-mono
                        text-[10px]
                        tracking-wider
                        text-white/20
                      "
                    >
                      0{index + 1}
                    </span>
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Bottom Area */}

            <motion.div
              initial={{
                opacity: 0,
                y: 20,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                delay: 0.6,
                duration: 0.6,
              }}
              className="
                relative
                z-10
                flex
                items-end
                justify-between
                border-t
                border-white/10
                pt-6
              "
            >
              <div>
                <p
                  className="
                    font-mono
                    text-[9px]
                    uppercase
                    tracking-[0.2em]
                    text-white/30
                  "
                >
                  Full Stack Web Developer
                </p>

                <p
                  className="
                    mt-2
                    text-sm
                    font-bold
                    text-white
                  "
                >
                  Building digital experiences.
                </p>

                <p
                  className="
                    mt-1
                    text-xs
                    text-white/30
                  "
                >
                  Laravel • Next.js • React
                </p>
              </div>

              {/* Rotating mark */}

              <motion.div
                animate={{
                  rotate: 360,
                }}
                transition={{
                  duration: 12,
                  repeat: Infinity,
                  ease: "linear",
                }}
                className="
                  flex
                  h-12
                  w-12
                  items-center
                  justify-center
                  rounded-full
                  border
                  border-[#ff5a1f]/40
                  bg-[#ff5a1f]/5
                  shadow-[0_0_30px_rgba(255,90,31,0.08)]
                "
              >
                <span className="text-lg text-[#ff5a1f]">
                  +
                </span>
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}