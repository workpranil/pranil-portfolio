"use client";

import { motion } from "framer-motion";
import {
  ArrowUpRight,
  Code2,
  MapPin,
  Terminal,
} from "lucide-react";

const stats = [
  {
    value: "8+",
    label: "Technologies",
  },
  {
    value: "1",
    label: "Featured Project",
  },
  {
    value: "1",
    label: "Internship",
  },
  {
    value: "∞",
    label: "Learning",
  },
];

const technologies = [
  "PHP",
  "Laravel",
  "HTML",
  "JavaScript",
  "C",
  "C++",
  "Core Java",
  "MySQL",
  "Bootstrap 5",
  "AdminLTE",
  "Git",
  "GitHub",
];

export default function About() {
  return (
    <section
      id="about"
      className="relative overflow-hidden bg-[#080808] text-white"
    >
      {/* =====================================================
          BACKGROUND
      ====================================================== */}

      <div className="pointer-events-none absolute inset-0">
        {/* Orange ambient light */}
        <div
          className="
            absolute
            -left-40
            top-1/3
            h-[500px]
            w-[500px]
            rounded-full
            bg-[#ff5a1f]/[0.035]
            blur-[140px]
          "
        />

        {/* Grid */}
        <div
          className="
            absolute
            inset-0
            opacity-[0.035]
            [background-image:linear-gradient(rgba(255,255,255,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.2)_1px,transparent_1px)]
            [background-size:100px_100px]
          "
        />

        {/* Top fade */}
        <div
          className="
            absolute
            inset-x-0
            top-0
            h-40
            bg-gradient-to-b
            from-[#080808]
            to-transparent
          "
        />
      </div>

      {/* =====================================================
          MAIN CONTAINER
      ====================================================== */}

      <div className="relative mx-auto max-w-[1600px] px-5 py-28 sm:px-8 sm:py-36 lg:px-12 lg:py-44">

        {/* =================================================
            SECTION HEADER
        ================================================= */}

        <div className="mb-20 flex items-end justify-between gap-8 border-b border-white/10 pb-6">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
            className="flex items-center gap-4"
          >
            <span className="h-px w-12 bg-[#ff5a1f]" />

            <span className="text-[10px] font-medium uppercase tracking-[0.3em] text-white/45 sm:text-xs">
              01 / About Me
            </span>
          </motion.div>

          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="hidden text-[10px] uppercase tracking-[0.25em] text-white/20 sm:block"
          >
            Developer / Builder / Learner
          </motion.span>
        </div>

        {/* =================================================
            INTRO
        ================================================= */}

        <div className="grid gap-16 lg:grid-cols-[1.15fr_0.85fr] lg:gap-24">

          {/* LEFT */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{
              duration: 0.9,
              ease: [0.16, 1, 0.3, 1],
            }}
          >
            <p className="mb-7 text-xs uppercase tracking-[0.25em] text-[#ff5a1f]">
              Who I am
            </p>

            <h2 className="max-w-5xl text-5xl font-semibold leading-[0.95] tracking-[-0.045em] sm:text-6xl lg:text-8xl">
              Turning ideas
              <br />
              <span className="text-white/35">
                into practical
              </span>
              <br />
              solutions.
            </h2>

            <div className="mt-10 max-w-2xl space-y-5">
              <p className="text-base leading-8 text-white/60 sm:text-lg">
                I&apos;m Pranil Malekar, a BSc IT student and aspiring
                PHP Laravel Developer who enjoys turning ideas into
                practical, modern and user-friendly web applications.
              </p>

              <p className="text-base leading-8 text-white/40 sm:text-lg">
                My development journey focuses on programming, web
                development, database management and software development.
                I enjoy building applications using Laravel, PHP, MySQL,
                JavaScript and Bootstrap while continuously improving my
                technical skills through projects and practical experience.
              </p>
            </div>

            {/* Location */}
            <div className="mt-10 flex items-center gap-3 text-white/40">
              <MapPin
                size={16}
                className="text-[#ff5a1f]"
              />

              <span className="text-xs uppercase tracking-[0.2em]">
                Urun Ishwarpur, Maharashtra, India
              </span>
            </div>
          </motion.div>

          {/* RIGHT */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{
              delay: 0.15,
              duration: 0.9,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="flex flex-col justify-end"
          >

            {/* Developer terminal */}
            <div className="relative overflow-hidden border border-white/10 bg-white/[0.02] p-6 backdrop-blur-sm sm:p-8">

              {/* Top bar */}
              <div className="mb-8 flex items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-3">
                  <Terminal
                    size={15}
                    className="text-[#ff5a1f]"
                  />

                  <span className="text-[9px] uppercase tracking-[0.25em] text-white/35">
                    developer.profile
                  </span>
                </div>

                <span className="h-2 w-2 rounded-full bg-[#ff5a1f] shadow-[0_0_12px_#ff5a1f]" />
              </div>

              {/* Code-style information */}
              <div className="space-y-5 font-mono text-xs sm:text-sm">

                <div>
                  <span className="text-[#ff5a1f]">
                    const
                  </span>{" "}
                  <span className="text-white/80">
                    developer
                  </span>{" "}
                  <span className="text-white/30">
                    =
                  </span>
                </div>

                <div className="pl-5 text-white/45">
                  {"{"}
                </div>

                <div className="pl-10">
                  <span className="text-white/30">
                    name:
                  </span>{" "}
                  <span className="text-white/75">
                    &quot;Pranil Malekar&quot;
                  </span>
                  <span className="text-white/25">
                    ,
                  </span>
                </div>

                <div className="pl-10">
                  <span className="text-white/30">
                    education:
                  </span>{" "}
                  <span className="text-white/65">
                    &quot;BSc IT&quot;
                  </span>
                  <span className="text-white/25">
                    ,
                  </span>
                </div>

                <div className="pl-10">
                  <span className="text-white/30">
                    role:
                  </span>{" "}
                  <span className="text-[#ff7a45]">
                    &quot;PHP Laravel Developer&quot;
                  </span>
                  <span className="text-white/25">
                    ,
                  </span>
                </div>

                <div className="pl-10">
                  <span className="text-white/30">
                    focus:
                  </span>{" "}
                  <span className="text-white/65">
                    &quot;Web Applications&quot;
                  </span>
                  <span className="text-white/25">
                    ,
                  </span>
                </div>

                <div className="pl-10">
                  <span className="text-white/30">
                    stack:
                  </span>{" "}
                  <span className="text-white/65">
                    &quot;Laravel / PHP / MySQL&quot;
                  </span>
                </div>

                <div className="pl-5 text-white/45">
                  {"}"}
                </div>
              </div>

              {/* Bottom accent */}
              <div className="absolute bottom-0 left-0 h-[2px] w-1/3 bg-[#ff5a1f]" />
            </div>

            {/* Availability */}
            <div className="mt-6 flex items-center gap-3">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#ff5a1f] opacity-50" />

                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#ff5a1f]" />
              </span>

              <span className="text-[10px] uppercase tracking-[0.22em] text-white/35">
                Always learning & building
              </span>
            </div>
          </motion.div>
        </div>

        {/* =================================================
            STATS
        ================================================= */}

        <div className="mt-28 border-y border-white/10">
          <div className="grid grid-cols-2 md:grid-cols-4">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{
                  opacity: 0,
                  y: 30,
                }}
                whileInView={{
                  opacity: 1,
                  y: 0,
                }}
                viewport={{
                  once: true,
                  amount: 0.4,
                }}
                transition={{
                  delay: index * 0.08,
                  duration: 0.6,
                }}
                className="
                  group
                  relative
                  border-white/10
                  px-5
                  py-8
                  transition-colors
                  hover:bg-white/[0.025]
                  sm:px-8
                  sm:py-10
                  md:border-r
                  md:last:border-r-0
                "
              >
                {/* Hover line */}
                <div
                  className="
                    absolute
                    left-0
                    top-0
                    h-[2px]
                    w-0
                    bg-[#ff5a1f]
                    transition-all
                    duration-500
                    group-hover:w-full
                  "
                />

                <p className="text-4xl font-semibold tracking-[-0.05em] text-white sm:text-5xl">
                  {stat.value}
                </p>

                <p className="mt-3 text-[9px] uppercase tracking-[0.25em] text-white/30">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* =================================================
            TECHNOLOGY STRIP
        ================================================= */}

        <motion.div
          initial={{
            opacity: 0,
            y: 30,
          }}
          whileInView={{
            opacity: 1,
            y: 0,
          }}
          viewport={{
            once: true,
            amount: 0.3,
          }}
          transition={{
            duration: 0.8,
          }}
          className="mt-20 grid gap-8 lg:grid-cols-[auto_1fr]"
        >

          {/* Label */}
          <div className="flex items-center gap-3">
            <Code2
              size={17}
              className="text-[#ff5a1f]"
            />

            <span className="text-[10px] uppercase tracking-[0.25em] text-white/35">
              Core Stack
            </span>
          </div>

          {/* Technologies */}
          <div className="flex flex-wrap gap-2">
            {technologies.map((tech, index) => (
              <motion.div
                key={tech}
                initial={{
                  opacity: 0,
                  scale: 0.9,
                }}
                whileInView={{
                  opacity: 1,
                  scale: 1,
                }}
                viewport={{
                  once: true,
                }}
                transition={{
                  delay: index * 0.05,
                  duration: 0.4,
                }}
                whileHover={{
                  y: -4,
                }}
                className="
                  group
                  flex
                  cursor-default
                  items-center
                  gap-2
                  border
                  border-white/10
                  bg-white/[0.02]
                  px-4
                  py-2.5
                  transition-all
                  duration-300
                  hover:border-[#ff5a1f]/40
                  hover:bg-[#ff5a1f]/[0.04]
                "
              >
                <span className="h-1 w-1 rounded-full bg-white/25 transition-colors group-hover:bg-[#ff5a1f]" />

                <span className="text-[9px] font-medium uppercase tracking-[0.18em] text-white/45 transition-colors group-hover:text-white/80">
                  {tech}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* =================================================
            BOTTOM STATEMENT
        ================================================= */}

        <motion.div
          initial={{
            opacity: 0,
          }}
          whileInView={{
            opacity: 1,
          }}
          viewport={{
            once: true,
          }}
          transition={{
            duration: 1,
          }}
          className="mt-28 flex flex-col justify-between gap-8 border-t border-white/10 pt-8 sm:flex-row sm:items-end"
        >
          <div>
            <p className="mb-3 text-[9px] uppercase tracking-[0.3em] text-white/25">
              My approach
            </p>

            <p className="max-w-2xl text-xl font-medium leading-relaxed tracking-[-0.02em] text-white/65 sm:text-2xl">
              Learn continuously. Build intentionally.
              <br />
              <span className="text-white">
                Improve every version.
              </span>
            </p>
          </div>

          <a
            href="#skills"
            className="
              group
              inline-flex
              items-center
              gap-3
              self-start
              text-[10px]
              font-medium
              uppercase
              tracking-[0.22em]
              text-white/40
              transition-colors
              hover:text-white
              sm:self-auto
            "
          >
            Explore my skills

            <span
              className="
                flex
                h-8
                w-8
                items-center
                justify-center
                rounded-full
                border
                border-white/10
                transition-all
                duration-300
                group-hover:border-[#ff5a1f]/50
                group-hover:bg-[#ff5a1f]
                group-hover:text-black
              "
            >
              <ArrowUpRight
                size={14}
                className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              />
            </span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}